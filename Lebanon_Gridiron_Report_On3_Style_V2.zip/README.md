# Lebanon Gridiron Report — V2

A free, responsive local football media site styled as a high-school sports/recruiting publication.

Features:
- Team hub and 2026 record
- Breaking/news area
- Schedule and results
- Recruiting board
- Player database
- Team snapshot and rankings
- Next-game card
- Tip submission/contact
- Mobile responsive layout

Current 2026 data is based on public schedule/roster information available October 5, 2026. Verify stats/roster information before publication.

Publish `index.html` on GitHub Pages or Cloudflare Pages for free.
